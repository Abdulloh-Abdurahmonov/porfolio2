const projects = [
  {
    src: "./img/Periodic table.png",
    name: "Periodic Table",
    in_tech: ["HTML", "CSS", "JS"],
    href: "https://aaa-periodic-neon-table.netlify.app/",
  },
  {
    src: "./img/Снимок экрана 2023-11-02 073154.png",
    name: "Todo List",
    in_tech: ["HTML", "CSS", "JS"],
    href: "https://aaa-green-todo-list.netlify.app/",
  },
  {
    src: "./img/Screenshot 2023-12-24 094855.png",
    name: "Chemical Mixture Precentage",
    in_tech: ["HTML", "CSS", "JS"],
    href: "https://aaa-mixture-precentage.netlify.app/",
  },
];
